package com.guevara.tecsupstore.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import kotlinx.coroutines.launch
import com.guevara.tecsupstore.ui.screens.*

@Composable
fun AppNavegacion() {
    val navController = rememberNavController()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                // ENCABEZADO
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .background(Color(0xFFEADDFF), shape = CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "MR",
                            color = Color(0xFF4F378B),
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column {
                        Text(
                            text = "Maria Rojas",
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                        Text(
                            text = "maria@tecsup.edu.pe",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                    }
                }

                HorizontalDivider(
                    modifier = Modifier.padding(bottom = 8.dp),
                    thickness = 0.5.dp,
                    color = Color.LightGray
                )

                // ÍTEMS
                NavigationDrawerItem(
                    label = { Text("Inicio", fontWeight = FontWeight.SemiBold) },
                    selected = currentRoute == Rutas.INICIO,
                    onClick = {
                        navController.navigate(Rutas.INICIO)
                        scope.launch { drawerState.close() }
                    },
                    icon = { Icon(Icons.Outlined.RadioButtonUnchecked, contentDescription = null) },
                    colors = NavigationDrawerItemDefaults.colors(
                        selectedContainerColor = Color(0xFFEADDFF),
                        unselectedContainerColor = Color.Transparent,
                    ),
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )

                NavigationDrawerItem(
                    label = { Text("Mis pedidos", fontWeight = FontWeight.SemiBold) },
                    selected = currentRoute == Rutas.PEDIDOS,
                    onClick = {
                        navController.navigate(Rutas.PEDIDOS)
                        scope.launch { drawerState.close() }
                    },
                    icon = { Icon(Icons.Outlined.RadioButtonUnchecked, contentDescription = null) },
                    colors = NavigationDrawerItemDefaults.colors(
                        selectedContainerColor = Color(0xFFEADDFF),
                        unselectedContainerColor = Color.Transparent,
                    ),
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )

                NavigationDrawerItem(
                    label = { Text("Favoritos", fontWeight = FontWeight.SemiBold) },
                    selected = currentRoute == Rutas.FAVORITOS,
                    onClick = {
                        navController.navigate(Rutas.FAVORITOS)
                        scope.launch { drawerState.close() }
                    },
                    icon = { Icon(Icons.Outlined.RadioButtonUnchecked, contentDescription = null) },
                    colors = NavigationDrawerItemDefaults.colors(
                        selectedContainerColor = Color(0xFFEADDFF),
                        unselectedContainerColor = Color.Transparent,
                    ),
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )

                NavigationDrawerItem(
                    label = { Text("Perfil", fontWeight = FontWeight.SemiBold) },
                    selected = currentRoute == Rutas.PERFIL,
                    onClick = {
                        navController.navigate(Rutas.PERFIL)
                        scope.launch { drawerState.close() }
                    },
                    icon = { Icon(Icons.Outlined.RadioButtonUnchecked, contentDescription = null) },
                    colors = NavigationDrawerItemDefaults.colors(
                        selectedContainerColor = Color(0xFFEADDFF),
                        unselectedContainerColor = Color.Transparent,
                    ),
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
            }
        }
    ) {
        // NAVEGACIÓN REAL
        NavHost(navController = navController, startDestination = Rutas.INICIO) {

            composable(Rutas.INICIO) {
                InicioScreen()
            }

            composable(Rutas.PEDIDOS) {
                // Coloca aquí la función de tu pantalla de Pedidos (si está en PantallasSecundarias.kt)
            }

            composable(Rutas.FAVORITOS) {
            }

            composable(Rutas.PERFIL) {
            }
        }
    }
}